--DOC_GEN_IMAGE --DOC_HIDE --DOC_NO_USAGE

require("awful.screen") --DOC_HIDE

screen[1]._resize {x = 175, width = 108, height = 198} --DOC_HIDE

    screen[1]:split()

--DOC_HIDE vim: filetype=lua:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:textwidth=80
