return {
    client       = require( "ruled.client"       ),
    notification = require( "ruled.notification" ),
}
